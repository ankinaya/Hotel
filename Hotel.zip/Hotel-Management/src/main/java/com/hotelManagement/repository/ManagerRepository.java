package com.hotelManagement.repository;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.hotelManagement.models.Manager;

public interface ManagerRepository extends MongoRepository<Manager,String>{

}
