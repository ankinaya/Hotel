package com.hotelManagement.models;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "Hotel")
public class Hotel {
@Id
String hotelId;
String hotelName;
String State;
String City;
String address;
String phoneNumber;
String emailId;
String Website;

public Hotel() {
	super();
}

public Hotel(String hotelId, String hotelName, String state, String city, String address, String phoneNumber,
		String emailId, String website) {
	super();
	this.hotelId = hotelId;
	this.hotelName = hotelName;
	this.State = state;
	this.City = city;
	this.address = address;
	this.phoneNumber = phoneNumber;
	this.emailId = emailId;
	this.Website = website;
}

public String getHotelId() {
	return hotelId;
}

public void setHotelId(String hotelId) {
	this.hotelId = hotelId;
}

public String getHotelName() {
	return hotelName;
}

public void setHotelName(String hotelName) {
	this.hotelName = hotelName;
}

public String getState() {
	return State;
}

public void setState(String state) {
	State = state;
}

public String getCity() {
	return City;
}

public void setCity(String city) {
	City = city;
}

public String getAddress() {
	return address;
}

public void setAddress(String address) {
	this.address = address;
}

public String getPhoneNumber() {
	return phoneNumber;
}

public void setPhoneNumber(String phoneNumber) {
	this.phoneNumber = phoneNumber;
}

public String getEmailId() {
	return emailId;
}

public void setEmailId(String emailId) {
	this.emailId = emailId;
}

public String getWebsite() {
	return Website;
}

public void setWebsite(String website) {
	Website = website;
}

@Override
public String toString() {
	return "Hotel [hotelId=" + hotelId + ", hotelName=" + hotelName + ", State=" + State + ", City=" + City
			+ ", address=" + address + ", phoneNumber=" + phoneNumber + ", emailId=" + emailId + ", Website=" + Website
			+ "]";
}





}
