package com.hotelManagement.models;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "Manager")
public class Manager {
	@Id
	String managerId;
	String managerName;
	String gender;
	String manageremailId;
	String mobileNumber;
	String managerState;
	String managerCity;
	String manageraddress;
	public Manager() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public Manager(String managerId, String managerName, String gender, String manageremailId, String mobileNumber,
			String managerState, String managerCity, String manageraddress) {
		super();
		this.managerId = managerId;
		this.managerName = managerName;
		this.gender = gender;
		this.manageremailId = manageremailId;
		this.mobileNumber = mobileNumber;
		this.managerState = managerState;
		this.managerCity = managerCity;
		this.manageraddress = manageraddress;
	}

	public String getManagerId() {
		return managerId;
	}
	public void setManagerId(String managerId) {
		this.managerId = managerId;
	}
	public String getManagerName() {
		return managerName;
	}
	public void setManagerName(String managerName) {
		this.managerName = managerName;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getManageremailId() {
		return manageremailId;
	}
	public void setManageremailId(String manageremailId) {
		this.manageremailId = manageremailId;
	}
	public String getMobileNumber() {
		return mobileNumber;
	}
	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	public String getManagerState() {
		return managerState;
	}
	public void setManagerState(String managerState) {
		this.managerState = managerState;
	}
	public String getManagerCity() {
		return managerCity;
	}
	public void setManagerCity(String managerCity) {
		this.managerCity = managerCity;
	}
	public String getManageraddress() {
		return manageraddress;
	}
	public void setManageraddress(String manageraddress) {
		this.manageraddress = manageraddress;
	}
	
	
	
	
	
}
