package com.hotelManagement.models;

public class Address {
	String State;
	String City;
	String address;
	public Address() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Address(String state, String city, String address) {
		super();
		State = state;
		City = city;
		this.address = address;
	}
	public String getState() {
		return State;
	}
	public void setState(String state) {
		State = state;
	}
	public String getCity() {
		return City;
	}
	public void setCity(String city) {
		City = city;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	
	
}
