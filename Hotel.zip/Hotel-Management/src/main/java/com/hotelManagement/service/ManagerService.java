package com.hotelManagement.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hotelManagement.models.Manager;
import com.hotelManagement.repository.ManagerRepository;

@Service
public class ManagerService implements IManagerService {

	@Autowired
	ManagerRepository managerRepository;

	public ManagerService() {
		super();
	}

	@Override
	public void createManager(Manager m) {
		managerRepository.save(m);
	}

	@Override
	public Manager findManager(String managerId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void updateManagerDetails(String managerId) {
		// TODO Auto-generated method stub
		
	}

	

}
