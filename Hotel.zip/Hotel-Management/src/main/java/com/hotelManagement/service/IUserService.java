package com.hotelManagement.service;

public interface IUserService {

}
